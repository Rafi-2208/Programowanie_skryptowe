def is_even(a):
    return not(a % 2)

if __name__ == '__main__':
    print(is_even(4))

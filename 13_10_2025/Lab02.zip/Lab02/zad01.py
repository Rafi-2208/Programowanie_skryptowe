# app01 
# Podaj z klawiatury dwie liczby pod zmienne a oraz b (funkcja input()).
# Następnie dodaj te dwie liczby i wyświetl wynik
# Zakładamy, że podajemy liczby całkowite lub zmiennoprzecinkowe (nie sprawdzamy tego)
a = float(input("Enter a number: "))
b = float(input("Enter another number: "))
c = a + b
print(c)

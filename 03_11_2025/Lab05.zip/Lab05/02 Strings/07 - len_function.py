phrase = """
It is a really long string
triple-quoted strings are used
to define multi-line strings
"""

#The len() function is used to count how many characters a string contains.

#Get the first half of the string stored in the variable phrase .
#Note: Remember about type conversion.
#Hint : Remember about string slicing.
pass #
first_half = phrase[:len(phrase)//2]

print(first_half)

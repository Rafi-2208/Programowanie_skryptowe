long_string = "This is a very long string!"


#Use negative index to get the '!' sign from long_string
#Hint : Use negative index.
pass
#
print(long_string[-1])

hello = "Hello"
world = 'World'

#Combining two strings using the + symbol is called concatenation.
#Use the hello and world variables to get a "Hello World" string.
#Hint : Use chained concatenation and one-space string \" \".
pass
#
print(hello+" "+world)      # Note: you should print "Hello World"

monty_python = "Monty Python"
print(monty_python)

print(monty_python.lower())    # print lower-cased version of the string


#Print monty_python in upper case.
print(monty_python.upper())
#Hint : Look at the lower() method usage.
pass
#
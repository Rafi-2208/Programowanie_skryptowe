hello = "hello"

#Use hello to get the "hellohellohellohellohellohellohellohellohellohello" string ( "hello" repeated 10 times).
#ten_of_hellos = hello operator 10
pass
#
print(hello*10)

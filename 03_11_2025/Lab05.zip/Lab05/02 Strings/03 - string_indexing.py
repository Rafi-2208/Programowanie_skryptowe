python = "Python"
print("h " + python[3])     # Note: string indexing starts with 0

#Use index operator to get "P" from "python" .
#Hint : Note that index starts with 0.
pass
#
print(python[0])
dont_worry = "Don't worry about apostrophes"
print(dont_worry)
print("\"Sweet\" is an ice-cream")

#Print out the following text using one string:
#The name of this ice-cream is   \"Sweet'n'Tasty"\
pass
#
print("The name of this ice-cream is   \\\"Sweet'n'Tasty\"\\")

ice_cream = "ice cream"
print("cream" in ice_cream)    # print boolean result directly


#Check if there is "ice" in "ice cream" .
#Hint : Use 'in' operator.
pass
#

print("ice" in ice_cream)

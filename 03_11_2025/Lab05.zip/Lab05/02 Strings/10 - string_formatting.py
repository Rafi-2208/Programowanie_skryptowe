name = "John"
print("Hello, PyCharm! My name is %s!" % name)     # Note: %s is inside the string, % is after the string

#Tell PyCharm how old you are.
#Hint 1 : Use %d special symbol.
pass
#

# Use all the string formatting methods you've learned
# .format
# f''

age = 19
print("my age is: {age}".format(age=age))
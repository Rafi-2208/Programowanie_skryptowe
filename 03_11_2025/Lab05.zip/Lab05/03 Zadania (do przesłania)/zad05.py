# 5. Wykorzystaj moduł calendar do wyświetlenia kalendarza na aktualny miesiąc (metoda month)
# i na cały bieżący rok (metoda calendar).
import calendar
print(calendar.month(2025,11))
print(calendar.calendar(2025))

# Utwórz nowy słownik
phone_book = {"John": 123, "Jane": 234, "Jerard": 345}
print(phone_book)

# Dodaj nowy element do słownika
phone_book["Jill"] = 456
print(phone_book)

print(phone_book.keys())

# Zadanie 1.
# Wyświetl wszystkie wartości z phone_book.
# Wskazówka: Użyj metody values().
print("")
print(phone_book.values())
pass
squares = [1, 4, 9, 16, 25]   # tworzymy nową listę
print(squares)

# Zadanie 1.
# Użyj wycinania listy, aby wydrukować [4, 9, 16].
# Wskazówka: Użyj slicing list lst[index1:index2]
pass
print(squares[1:4])

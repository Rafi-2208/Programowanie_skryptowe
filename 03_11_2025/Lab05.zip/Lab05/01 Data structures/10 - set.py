# Zbiory

z1 = set('123455555') #
print(z1)
z2 = {'3','5','7','8','9','0','0','0','0'}
print(z2)

print(z1 - z2) # difference
print(set.difference(z1, z2))
print(z1 & z2) # intersection
print(set.intersection(z1, z2))
print(z1 | z2) # union
print(set.union(z1, z2))
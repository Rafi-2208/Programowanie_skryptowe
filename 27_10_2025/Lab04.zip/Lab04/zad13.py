# Dodatkowe (niewymagane)
# 13. Gramy w kółko i krzyżyk (3x3) - tekstowo
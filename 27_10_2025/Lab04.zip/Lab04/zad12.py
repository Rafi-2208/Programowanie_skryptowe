# Dodatkowe (niewymagane)
# 12. Gramy w szubienicę tekstowo
